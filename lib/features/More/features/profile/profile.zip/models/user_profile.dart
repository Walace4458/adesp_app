class UserProfile {
  String? name;
  String? avatarPath;

  String? birthDate;
  String? gender;

  String? phone;
  String? email;

  String? cpf;
  String? rg;

  UserProfile({
    this.name,
    this.avatarPath,
    this.birthDate,
    this.gender,
    this.phone,
    this.email,
    this.cpf,
    this.rg,
  });

  double get completion {
    int total = 6;
    int filled = 0;

    if (name != null && name!.isNotEmpty) filled++;
    if (birthDate != null && birthDate!.isNotEmpty) filled++;
    if (gender != null && gender!.isNotEmpty) filled++;
    if (phone != null && phone!.isNotEmpty) filled++;
    if (email != null && email!.isNotEmpty) filled++;
    if (cpf != null && cpf!.isNotEmpty) filled++;

    return filled / total;
  }
}